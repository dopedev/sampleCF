sap.ui.define([
	"ns/ui/test/unit/controller/S1.controller"
], function () {
	"use strict";
});